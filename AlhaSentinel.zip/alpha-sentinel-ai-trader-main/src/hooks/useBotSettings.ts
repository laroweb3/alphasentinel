import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";
import { toast } from "sonner";

export interface BotSettings {
  weexApiKey: string;
  weexApiSecret: string;
  maxDailyLoss: number;
  maxDrawdown: number;
  maxConsecutiveLosses: number;
  leverageCap: number;
  cooldownMinutes: number;
  activePairs: string[];
  isBotActive: boolean;
}

const defaultSettings: BotSettings = {
  weexApiKey: "",
  weexApiSecret: "",
  maxDailyLoss: 3,
  maxDrawdown: 8,
  maxConsecutiveLosses: 3,
  leverageCap: 5,
  cooldownMinutes: 30,
  activePairs: ["BTC/USDT", "ETH/USDT", "SOL/USDT"],
  isBotActive: false,
};

export const useBotSettings = () => {
  const { user } = useAuth();
  const [settings, setSettings] = useState<BotSettings>(defaultSettings);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchSettings();
    } else {
      setSettings(defaultSettings);
      setLoading(false);
    }
  }, [user]);

  const fetchSettings = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("bot_settings")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setSettings({
          weexApiKey: data.weex_api_key || "",
          weexApiSecret: data.weex_api_secret || "",
          maxDailyLoss: Number(data.max_daily_loss),
          maxDrawdown: Number(data.max_drawdown),
          maxConsecutiveLosses: data.max_consecutive_losses,
          leverageCap: data.leverage_cap,
          cooldownMinutes: data.cooldown_minutes,
          activePairs: data.active_pairs || defaultSettings.activePairs,
          isBotActive: data.is_bot_active,
        });
      }
    } catch (error) {
      console.error("Error fetching settings:", error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async (newSettings: BotSettings) => {
    if (!user) {
      toast.error("Please sign in to save settings");
      return;
    }

    try {
      const { error } = await supabase
        .from("bot_settings")
        .upsert({
          user_id: user.id,
          weex_api_key: newSettings.weexApiKey,
          weex_api_secret: newSettings.weexApiSecret,
          max_daily_loss: newSettings.maxDailyLoss,
          max_drawdown: newSettings.maxDrawdown,
          max_consecutive_losses: newSettings.maxConsecutiveLosses,
          leverage_cap: newSettings.leverageCap,
          cooldown_minutes: newSettings.cooldownMinutes,
          active_pairs: newSettings.activePairs,
          is_bot_active: newSettings.isBotActive,
        });

      if (error) throw error;

      setSettings(newSettings);
      toast.success("Settings saved successfully");
    } catch (error: any) {
      toast.error("Failed to save settings: " + error.message);
    }
  };

  const toggleBot = async () => {
    const newSettings = { ...settings, isBotActive: !settings.isBotActive };
    await saveSettings(newSettings);
  };

  return { settings, loading, saveSettings, toggleBot };
};
