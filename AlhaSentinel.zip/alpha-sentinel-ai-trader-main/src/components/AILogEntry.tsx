import { cn } from "@/lib/utils";

interface AILog {
  time: string;
  pair: string;
  regime: string;
  signal: "LONG" | "SHORT" | "HOLD";
  confidence: number;
  position_size: number;
  leverage: number;
  risk_score: number;
  ai_decision: "ENTER" | "EXIT" | "HOLD";
  reason: string;
}

interface AILogEntryProps {
  log: AILog;
}

export const AILogEntry = ({ log }: AILogEntryProps) => {
  const signalColor = {
    LONG: "text-success",
    SHORT: "text-destructive",
    HOLD: "text-muted-foreground",
  };

  const decisionColor = {
    ENTER: "bg-success/20 text-success border-success/30",
    EXIT: "bg-destructive/20 text-destructive border-destructive/30",
    HOLD: "bg-muted text-muted-foreground border-muted",
  };

  return (
    <div className="p-3 rounded-lg bg-card/50 border border-border hover:border-primary/30 transition-colors font-mono text-sm">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-primary">{log.pair}</span>
          <span className={cn("font-bold", signalColor[log.signal])}>{log.signal}</span>
          <span className={cn("px-2 py-0.5 rounded text-xs border", decisionColor[log.ai_decision])}>
            {log.ai_decision}
          </span>
        </div>
        <span className="text-xs text-muted-foreground">
          {new Date(log.time).toLocaleTimeString()}
        </span>
      </div>
      
      <div className="grid grid-cols-4 gap-2 text-xs mb-2">
        <div>
          <span className="text-muted-foreground">Regime: </span>
          <span className="text-foreground">{log.regime}</span>
        </div>
        <div>
          <span className="text-muted-foreground">Size: </span>
          <span className="text-foreground">{(log.position_size * 100).toFixed(0)}%</span>
        </div>
        <div>
          <span className="text-muted-foreground">Lev: </span>
          <span className="text-foreground">{log.leverage}x</span>
        </div>
        <div>
          <span className="text-muted-foreground">Risk: </span>
          <span className={cn(
            log.risk_score < 0.3 ? "text-success" : 
            log.risk_score < 0.6 ? "text-warning" : "text-destructive"
          )}>
            {(log.risk_score * 100).toFixed(0)}%
          </span>
        </div>
      </div>
      
      <p className="text-xs text-muted-foreground italic">"{log.reason}"</p>
    </div>
  );
};
