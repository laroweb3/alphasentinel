import { cn } from "@/lib/utils";

interface StatusIndicatorProps {
  status: "online" | "offline" | "warning";
  label?: string;
  size?: "sm" | "md" | "lg";
}

export const StatusIndicator = ({ status, label, size = "md" }: StatusIndicatorProps) => {
  const sizeClasses = {
    sm: "h-2 w-2",
    md: "h-3 w-3",
    lg: "h-4 w-4",
  };

  const statusClasses = {
    online: "bg-success box-glow-success",
    offline: "bg-destructive box-glow-destructive",
    warning: "bg-warning",
  };

  return (
    <div className="flex items-center gap-2">
      <div className={cn("rounded-full animate-pulse-glow", sizeClasses[size], statusClasses[status])} />
      {label && <span className="text-sm text-muted-foreground font-mono">{label}</span>}
    </div>
  );
};
