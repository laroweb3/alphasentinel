import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: LucideIcon;
  trend?: "up" | "down" | "neutral";
  variant?: "default" | "success" | "danger" | "warning";
}

export const MetricCard = ({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  trend,
  variant = "default" 
}: MetricCardProps) => {
  const variantClasses = {
    default: "border-border",
    success: "border-success/30 box-glow-success",
    danger: "border-destructive/30 box-glow-destructive",
    warning: "border-warning/30",
  };

  const valueClasses = {
    default: "text-foreground",
    success: "text-success text-glow-success",
    danger: "text-destructive text-glow-destructive",
    warning: "text-warning",
  };

  return (
    <div className={cn(
      "relative overflow-hidden rounded-lg border bg-card p-4 gradient-border",
      variantClasses[variant]
    )}>
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            {title}
          </p>
          <p className={cn("text-2xl font-bold font-mono", valueClasses[variant])}>
            {value}
          </p>
          {subtitle && (
            <p className="text-xs text-muted-foreground font-mono">{subtitle}</p>
          )}
        </div>
        {Icon && (
          <div className={cn(
            "p-2 rounded-md bg-muted/50",
            variant === "success" && "text-success",
            variant === "danger" && "text-destructive",
            variant === "warning" && "text-warning",
            variant === "default" && "text-primary"
          )}>
            <Icon className="h-5 w-5" />
          </div>
        )}
      </div>
      {trend && (
        <div className={cn(
          "absolute bottom-0 left-0 right-0 h-0.5",
          trend === "up" && "bg-gradient-to-r from-success/0 via-success to-success/0",
          trend === "down" && "bg-gradient-to-r from-destructive/0 via-destructive to-destructive/0",
          trend === "neutral" && "bg-gradient-to-r from-primary/0 via-primary to-primary/0"
        )} />
      )}
    </div>
  );
};
