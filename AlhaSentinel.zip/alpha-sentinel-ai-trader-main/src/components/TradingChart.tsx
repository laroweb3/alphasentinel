import { useMemo, useState } from "react";
import {
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { cn } from "@/lib/utils";

interface OHLCV {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface TradingChartProps {
  pair: string;
  data?: OHLCV[];
  height?: number;
}

// Generate mock OHLCV data
const generateMockData = (pair: string): OHLCV[] => {
  const data: OHLCV[] = [];
  const basePrice = pair.includes("BTC") ? 97000 : pair.includes("ETH") ? 3250 : 185;
  const now = new Date();

  for (let i = 48; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 30 * 60000);
    const volatility = basePrice * 0.002;
    const trend = Math.sin(i / 10) * basePrice * 0.01;
    
    const open = basePrice + trend + (Math.random() - 0.5) * volatility;
    const close = open + (Math.random() - 0.5) * volatility;
    const high = Math.max(open, close) + Math.random() * volatility * 0.5;
    const low = Math.min(open, close) - Math.random() * volatility * 0.5;
    const volume = 1000000 + Math.random() * 5000000;

    data.push({
      time: time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      open,
      high,
      low,
      close,
      volume,
    });
  }
  return data;
};

const CustomCandlestick = ({ x, y, width, payload }: any) => {
  if (!payload) return null;
  
  const { open, close, high, low } = payload;
  const isUp = close >= open;
  const color = isUp ? "hsl(142, 76%, 45%)" : "hsl(0, 84%, 55%)";
  const bodyHeight = Math.abs(close - open);
  const candleY = Math.min(open, close);

  return (
    <g>
      {/* Wick */}
      <line
        x1={x + width / 2}
        y1={y(high)}
        x2={x + width / 2}
        y2={y(low)}
        stroke={color}
        strokeWidth={1}
      />
      {/* Body */}
      <rect
        x={x + 2}
        y={y(Math.max(open, close))}
        width={width - 4}
        height={Math.max(y(Math.min(open, close)) - y(Math.max(open, close)), 1)}
        fill={isUp ? color : color}
        stroke={color}
      />
    </g>
  );
};

export const TradingChart = ({ pair, data, height = 280 }: TradingChartProps) => {
  const chartData = useMemo(() => data || generateMockData(pair), [data, pair]);
  
  const currentPrice = chartData[chartData.length - 1]?.close || 0;
  const firstPrice = chartData[0]?.close || 0;
  const priceChange = currentPrice - firstPrice;
  const priceChangePercent = ((priceChange / firstPrice) * 100).toFixed(2);
  const isUp = priceChange >= 0;

  const minPrice = Math.min(...chartData.map((d) => d.low));
  const maxPrice = Math.max(...chartData.map((d) => d.high));
  const maxVolume = Math.max(...chartData.map((d) => d.volume));

  return (
    <div className="rounded-lg border border-border bg-card/30">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-border">
        <div className="flex items-center gap-3">
          <span className="font-mono font-bold text-foreground">{pair}</span>
          <span className="text-xs text-muted-foreground">30m</span>
        </div>
        <div className="flex items-center gap-4 font-mono text-sm">
          <span className={cn("font-bold", isUp ? "text-success" : "text-destructive")}>
            ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
          <span className={cn("text-xs", isUp ? "text-success" : "text-destructive")}>
            {isUp ? "+" : ""}{priceChangePercent}%
          </span>
        </div>
      </div>

      {/* Chart */}
      <div className="p-2">
        <ResponsiveContainer width="100%" height={height}>
          <ComposedChart data={chartData} margin={{ top: 10, right: 10, bottom: 0, left: 0 }}>
            <XAxis
              dataKey="time"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10, fontFamily: "JetBrains Mono" }}
              interval="preserveStartEnd"
            />
            <YAxis
              domain={[minPrice * 0.999, maxPrice * 1.001]}
              axisLine={false}
              tickLine={false}
              tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10, fontFamily: "JetBrains Mono" }}
              orientation="right"
              tickFormatter={(v) => v.toLocaleString()}
              width={70}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(222, 47%, 8%)",
                border: "1px solid hsl(222, 30%, 18%)",
                borderRadius: "6px",
                fontFamily: "JetBrains Mono",
                fontSize: "12px",
              }}
              labelStyle={{ color: "hsl(185, 100%, 50%)" }}
              formatter={(value: number, name: string) => [
                `$${value.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
                name.charAt(0).toUpperCase() + name.slice(1),
              ]}
            />
            <ReferenceLine y={currentPrice} stroke="hsl(185, 100%, 50%)" strokeDasharray="3 3" strokeOpacity={0.5} />
            
            {/* Volume bars at bottom */}
            <Bar
              dataKey="volume"
              fill="hsl(185, 100%, 50%)"
              fillOpacity={0.15}
              yAxisId="volume"
            />
            
            {/* Price line */}
            <Line
              type="monotone"
              dataKey="close"
              stroke={isUp ? "hsl(142, 76%, 45%)" : "hsl(0, 84%, 55%)"}
              strokeWidth={1.5}
              dot={false}
              activeDot={{ r: 3, fill: "hsl(185, 100%, 50%)" }}
            />
            
            <YAxis
              yAxisId="volume"
              domain={[0, maxVolume * 4]}
              hide
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
