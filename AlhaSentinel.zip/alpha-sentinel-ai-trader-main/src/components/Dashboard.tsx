import { useState, useEffect } from "react";
import { 
  Wallet, 
  TrendingUp, 
  Activity,
  AlertTriangle,
  Zap,
  BarChart3,
  LogOut,
  User
} from "lucide-react";
import { StatusIndicator } from "./StatusIndicator";
import { MetricCard } from "./MetricCard";
import { RegimeIndicator } from "./RegimeIndicator";
import { AILogEntry } from "./AILogEntry";
import { RiskGauge } from "./RiskGauge";
import { PositionCard } from "./PositionCard";
import { KillSwitch } from "./KillSwitch";
import { TradeHistory } from "./TradeHistory";
import { TradingChart } from "./TradingChart";
import { PriceTicker } from "./PriceTicker";
import { OrderBook } from "./OrderBook";
import { SettingsPanel } from "./SettingsPanel";
import { AuthModal } from "./AuthModal";
import { useAuth } from "@/hooks/useAuth";
import { useBotSettings } from "@/hooks/useBotSettings";

// Mock data
const mockLogs = [
  {
    time: "2026-01-08T14:32:00Z",
    pair: "ETH/USDT",
    regime: "TREND",
    signal: "LONG" as const,
    confidence: 0.81,
    position_size: 0.1,
    leverage: 3,
    risk_score: 0.28,
    ai_decision: "ENTER" as const,
    reason: "Trend continuation + low volatility",
  },
  {
    time: "2026-01-08T14:15:00Z",
    pair: "BTC/USDT",
    regime: "RANGE",
    signal: "SHORT" as const,
    confidence: 0.72,
    position_size: 0.05,
    leverage: 2,
    risk_score: 0.45,
    ai_decision: "ENTER" as const,
    reason: "Mean reversion at resistance",
  },
];

const mockPositions = [
  {
    id: "1",
    pair: "ETH/USDT",
    side: "LONG" as const,
    entryPrice: 3245.50,
    currentPrice: 3298.20,
    size: 1500,
    leverage: 3,
    pnl: 48.75,
    pnlPercent: 1.62,
  },
];

const mockTrades = [
  { id: "1", time: "2026-01-08T12:30:00Z", pair: "ETH/USDT", side: "LONG" as const, entryPrice: 3180, exitPrice: 3245, pnl: 65, pnlPercent: 2.04 },
  { id: "2", time: "2026-01-08T11:15:00Z", pair: "BTC/USDT", side: "LONG" as const, entryPrice: 96800, exitPrice: 97200, pnl: 40, pnlPercent: 0.41 },
  { id: "3", time: "2026-01-08T10:00:00Z", pair: "SOL/USDT", side: "SHORT" as const, entryPrice: 185.50, exitPrice: 188.20, pnl: -27, pnlPercent: -1.45 },
];

const tickerData = [
  { pair: "BTC/USDT", price: 97150, change24h: 2.34, volume24h: 1250000000 },
  { pair: "ETH/USDT", price: 3265, change24h: 1.87, volume24h: 580000000 },
  { pair: "SOL/USDT", price: 186.20, change24h: -0.45, volume24h: 320000000 },
  { pair: "ARB/USDT", price: 1.82, change24h: 4.21, volume24h: 95000000 },
];

export const Dashboard = () => {
  const { user, loading: authLoading, signOut } = useAuth();
  const { settings, saveSettings, toggleBot } = useBotSettings();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedPair, setSelectedPair] = useState("BTC/USDT");
  const [regime, setRegime] = useState<"TREND" | "RANGE" | "HIGH_VOL" | "NO_TRADE">("TREND");

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Cycle through regimes for demo
  useEffect(() => {
    const regimes: Array<"TREND" | "RANGE" | "HIGH_VOL" | "NO_TRADE"> = ["TREND", "RANGE", "HIGH_VOL", "NO_TRADE"];
    let index = 0;
    const timer = setInterval(() => {
      index = (index + 1) % regimes.length;
      setRegime(regimes[index]);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Scan line effect */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent animate-scan-line" />
      </div>

      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center box-glow-primary">
                  <Zap className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-lg font-bold text-foreground tracking-tight">
                    ALPHA<span className="text-primary">-SENTINEL</span>
                  </h1>
                </div>
              </div>
              <div className="h-6 w-px bg-border" />
              <StatusIndicator status={settings.isBotActive ? "online" : "offline"} label={settings.isBotActive ? "LIVE" : "STOPPED"} />
            </div>

            <div className="flex items-center gap-4">
              {/* Ticker strip */}
              <div className="hidden xl:block max-w-md">
                <PriceTicker items={tickerData} selectedPair={selectedPair} onSelectPair={setSelectedPair} />
              </div>

              <div className="h-6 w-px bg-border" />

              <div className="text-right hidden sm:block">
                <p className="text-xs text-muted-foreground">UTC</p>
                <p className="font-mono text-sm text-foreground">
                  {currentTime.toISOString().slice(11, 19)}
                </p>
              </div>

              <SettingsPanel settings={settings} onSave={saveSettings} />

              {user ? (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground font-mono hidden md:block">
                    {user.email?.split("@")[0]}
                  </span>
                  <button
                    onClick={signOut}
                    className="p-2 rounded-lg bg-muted/50 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                    title="Sign out"
                  >
                    <LogOut className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowAuthModal(true)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30 transition-colors font-mono text-sm"
                >
                  <User className="h-4 w-4" />
                  Sign In
                </button>
              )}

              <KillSwitch isActive={settings.isBotActive} onToggle={toggleBot} />
            </div>
          </div>
        </div>
      </header>

      <main className="p-4 space-y-4">
        {/* Top Metrics Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <MetricCard
            title="Balance"
            value="$12,847.32"
            subtitle="+$847.32"
            icon={Wallet}
            variant="success"
            trend="up"
          />
          <MetricCard
            title="Total PnL"
            value="+6.82%"
            subtitle="Competition"
            icon={TrendingUp}
            variant="success"
            trend="up"
          />
          <MetricCard
            title="Active"
            value="2"
            subtitle="Positions"
            icon={Activity}
            variant="default"
          />
          <MetricCard
            title="Win Rate"
            value="75%"
            subtitle="12 trades"
            icon={BarChart3}
            variant="default"
          />
        </div>

        {/* Mobile Ticker */}
        <div className="xl:hidden">
          <PriceTicker items={tickerData} selectedPair={selectedPair} onSelectPair={setSelectedPair} />
        </div>

        {/* Main Grid - Cryptowatch style */}
        <div className="grid grid-cols-12 gap-4">
          {/* Left Panel - Chart & Order Book */}
          <div className="col-span-12 lg:col-span-8 space-y-4">
            <TradingChart pair={selectedPair} height={300} />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <OrderBook pair={selectedPair} />
              
              {/* Positions */}
              <div className="space-y-3">
                <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                  <TrendingUp className="h-3 w-3 text-success" />
                  Open Positions
                </h2>
                {mockPositions.map((position) => (
                  <PositionCard key={position.id} position={position} />
                ))}
                {mockPositions.length === 0 && (
                  <div className="p-4 rounded-lg border border-dashed border-border text-center">
                    <p className="text-sm text-muted-foreground font-mono">No open positions</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Panel - AI & Risk */}
          <div className="col-span-12 lg:col-span-4 space-y-4">
            {/* Regime */}
            <RegimeIndicator regime={regime} confidence={0.81} />

            {/* Risk Engine */}
            <div className="p-3 rounded-lg border border-border bg-card/30">
              <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                <AlertTriangle className="h-3 w-3 text-warning" />
                Risk Engine
              </h2>
              <div className="space-y-3">
                <RiskGauge value={2.1} max={settings.maxDrawdown} label="Drawdown" danger={75} warning={50} />
                <RiskGauge value={0.8} max={settings.maxDailyLoss} label="Daily Loss" danger={80} warning={60} />
                <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-border/50">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Losses:</span>
                    <span className="text-success">0/{settings.maxConsecutiveLosses}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Lev:</span>
                    <span className="text-foreground">{settings.leverageCap}x</span>
                  </div>
                </div>
              </div>
            </div>

            {/* AI Logs */}
            <div>
              <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-2">
                <Zap className="h-3 w-3 text-primary" />
                AI Decisions
              </h2>
              <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                {mockLogs.map((log, index) => (
                  <AILogEntry key={index} log={log} />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Trade History */}
        <div className="rounded-lg border border-border bg-card/30 p-3">
          <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
            Trade History
          </h2>
          <TradeHistory trades={mockTrades} />
        </div>

        {/* Footer Stats */}
        <div className="flex flex-wrap items-center justify-between gap-4 py-2 px-3 rounded-lg border border-border bg-card/20 font-mono text-xs">
          <div className="flex items-center gap-4">
            <div>
              <span className="text-muted-foreground">API: </span>
              <span className={settings.weexApiKey ? "text-success" : "text-warning"}>
                {settings.weexApiKey ? "WEEX Connected" : "Not configured"}
              </span>
            </div>
            <div>
              <span className="text-muted-foreground">Latency: </span>
              <span className="text-foreground">42ms</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div>
              <span className="text-muted-foreground">Model: </span>
              <span className="text-primary">XGBoost + PPO</span>
            </div>
            <div>
              <span className="text-muted-foreground">Pairs: </span>
              <span className="text-foreground">{settings.activePairs.join(", ")}</span>
            </div>
          </div>
        </div>
      </main>

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => {}}
      />
    </div>
  );
};
