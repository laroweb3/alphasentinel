import { useState } from "react";
import { cn } from "@/lib/utils";
import { ShieldOff, Shield } from "lucide-react";

interface KillSwitchProps {
  isActive: boolean;
  onToggle: () => void;
}

export const KillSwitch = ({ isActive, onToggle }: KillSwitchProps) => {
  const [isConfirming, setIsConfirming] = useState(false);

  const handleClick = () => {
    if (isActive && !isConfirming) {
      setIsConfirming(true);
      setTimeout(() => setIsConfirming(false), 3000);
      return;
    }
    onToggle();
    setIsConfirming(false);
  };

  return (
    <button
      onClick={handleClick}
      className={cn(
        "relative px-6 py-3 rounded-lg font-mono font-bold text-sm uppercase tracking-wider transition-all duration-300",
        "border-2 flex items-center gap-2",
        isActive
          ? "bg-destructive/20 border-destructive text-destructive hover:bg-destructive/30 box-glow-destructive"
          : "bg-success/20 border-success text-success hover:bg-success/30 box-glow-success"
      )}
    >
      {isActive ? (
        <>
          <ShieldOff className="h-5 w-5" />
          {isConfirming ? "CONFIRM STOP" : "KILL SWITCH"}
        </>
      ) : (
        <>
          <Shield className="h-5 w-5" />
          ACTIVATE BOT
        </>
      )}
    </button>
  );
};
