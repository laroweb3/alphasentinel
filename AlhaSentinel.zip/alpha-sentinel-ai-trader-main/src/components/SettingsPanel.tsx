import { useState } from "react";
import { Settings, Key, Shield, Zap, Eye, EyeOff, Save, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

interface BotSettings {
  weexApiKey: string;
  weexApiSecret: string;
  maxDailyLoss: number;
  maxDrawdown: number;
  maxConsecutiveLosses: number;
  leverageCap: number;
  cooldownMinutes: number;
  activePairs: string[];
}

interface SettingsPanelProps {
  settings: BotSettings;
  onSave: (settings: BotSettings) => void;
}

export const SettingsPanel = ({ settings, onSave }: SettingsPanelProps) => {
  const [localSettings, setLocalSettings] = useState(settings);
  const [showApiKey, setShowApiKey] = useState(false);
  const [showApiSecret, setShowApiSecret] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const handleSave = () => {
    onSave(localSettings);
    setIsOpen(false);
  };

  const availablePairs = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "ARB/USDT", "MATIC/USDT", "AVAX/USDT"];

  const togglePair = (pair: string) => {
    setLocalSettings((prev) => ({
      ...prev,
      activePairs: prev.activePairs.includes(pair)
        ? prev.activePairs.filter((p) => p !== pair)
        : [...prev.activePairs, pair],
    }));
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <button className="p-2 rounded-lg bg-muted/50 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
          <Settings className="h-5 w-5" />
        </button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px] bg-card border-border overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2 text-foreground">
            <Settings className="h-5 w-5 text-primary" />
            Bot Configuration
          </SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* WEEX API Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-foreground">
              <Key className="h-4 w-4 text-primary" />
              WEEX API Credentials
            </div>
            
            <div className="space-y-3 p-4 rounded-lg bg-muted/30 border border-border">
              <div className="space-y-2">
                <Label className="text-xs text-muted-foreground">API Key</Label>
                <div className="relative">
                  <Input
                    type={showApiKey ? "text" : "password"}
                    value={localSettings.weexApiKey}
                    onChange={(e) => setLocalSettings({ ...localSettings, weexApiKey: e.target.value })}
                    placeholder="Enter your WEEX API key"
                    className="font-mono text-sm bg-background border-border pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs text-muted-foreground">API Secret</Label>
                <div className="relative">
                  <Input
                    type={showApiSecret ? "text" : "password"}
                    value={localSettings.weexApiSecret}
                    onChange={(e) => setLocalSettings({ ...localSettings, weexApiSecret: e.target.value })}
                    placeholder="Enter your WEEX API secret"
                    className="font-mono text-sm bg-background border-border pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiSecret(!showApiSecret)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showApiSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <p className="text-xs text-muted-foreground">
                Get your API credentials from{" "}
                <a href="https://www.weex.com" target="_blank" rel="noopener" className="text-primary hover:underline">
                  WEEX Exchange
                </a>
              </p>
            </div>
          </div>

          {/* Risk Management Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-foreground">
              <Shield className="h-4 w-4 text-warning" />
              Risk Management
            </div>

            <div className="space-y-4 p-4 rounded-lg bg-muted/30 border border-border">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Max Daily Loss (%)</Label>
                  <Input
                    type="number"
                    min={0.5}
                    max={10}
                    step={0.5}
                    value={localSettings.maxDailyLoss}
                    onChange={(e) => setLocalSettings({ ...localSettings, maxDailyLoss: parseFloat(e.target.value) })}
                    className="font-mono bg-background border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Max Drawdown (%)</Label>
                  <Input
                    type="number"
                    min={1}
                    max={20}
                    step={0.5}
                    value={localSettings.maxDrawdown}
                    onChange={(e) => setLocalSettings({ ...localSettings, maxDrawdown: parseFloat(e.target.value) })}
                    className="font-mono bg-background border-border"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Max Consecutive Losses</Label>
                  <Input
                    type="number"
                    min={1}
                    max={10}
                    value={localSettings.maxConsecutiveLosses}
                    onChange={(e) => setLocalSettings({ ...localSettings, maxConsecutiveLosses: parseInt(e.target.value) })}
                    className="font-mono bg-background border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Leverage Cap</Label>
                  <Input
                    type="number"
                    min={1}
                    max={20}
                    value={localSettings.leverageCap}
                    onChange={(e) => setLocalSettings({ ...localSettings, leverageCap: parseInt(e.target.value) })}
                    className="font-mono bg-background border-border"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs text-muted-foreground">Cooldown After Loss (minutes)</Label>
                <Input
                  type="number"
                  min={5}
                  max={120}
                  step={5}
                  value={localSettings.cooldownMinutes}
                  onChange={(e) => setLocalSettings({ ...localSettings, cooldownMinutes: parseInt(e.target.value) })}
                  className="font-mono bg-background border-border"
                />
              </div>
            </div>
          </div>

          {/* Trading Pairs Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-foreground">
              <Zap className="h-4 w-4 text-primary" />
              Active Trading Pairs
            </div>

            <div className="flex flex-wrap gap-2 p-4 rounded-lg bg-muted/30 border border-border">
              {availablePairs.map((pair) => {
                const isActive = localSettings.activePairs.includes(pair);
                return (
                  <button
                    key={pair}
                    onClick={() => togglePair(pair)}
                    className={cn(
                      "px-3 py-1.5 rounded-md font-mono text-sm transition-all",
                      isActive
                        ? "bg-primary/20 text-primary border border-primary/30"
                        : "bg-muted/50 text-muted-foreground border border-transparent hover:border-border"
                    )}
                  >
                    {pair}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Save Button */}
          <div className="flex gap-3 pt-4 border-t border-border">
            <Button
              variant="outline"
              onClick={() => setIsOpen(false)}
              className="flex-1 border-border hover:bg-muted"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Settings
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};
