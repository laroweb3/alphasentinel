import { cn } from "@/lib/utils";

interface RiskGaugeProps {
  value: number;
  max: number;
  label: string;
  unit?: string;
  danger?: number;
  warning?: number;
}

export const RiskGauge = ({ 
  value, 
  max, 
  label, 
  unit = "%",
  danger = 80,
  warning = 50 
}: RiskGaugeProps) => {
  const percentage = (value / max) * 100;
  
  const getColor = () => {
    if (percentage >= danger) return "destructive";
    if (percentage >= warning) return "warning";
    return "success";
  };

  const color = getColor();

  const colorClasses = {
    success: "bg-success",
    warning: "bg-warning",
    destructive: "bg-destructive",
  };

  const glowClasses = {
    success: "box-glow-success",
    warning: "",
    destructive: "box-glow-destructive",
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground uppercase tracking-wider">{label}</span>
        <span className={cn(
          "font-mono font-bold",
          color === "success" && "text-success",
          color === "warning" && "text-warning",
          color === "destructive" && "text-destructive"
        )}>
          {value.toFixed(1)}{unit}
        </span>
      </div>
      <div className="h-2 bg-muted rounded-full overflow-hidden">
        <div 
          className={cn(
            "h-full rounded-full transition-all duration-500",
            colorClasses[color],
            glowClasses[color]
          )}
          style={{ width: `${Math.min(percentage, 100)}%` }}
        />
      </div>
      <div className="flex justify-between text-xs text-muted-foreground font-mono">
        <span>0{unit}</span>
        <span className="text-warning">{warning}%</span>
        <span className="text-destructive">{danger}%</span>
        <span>{max}{unit}</span>
      </div>
    </div>
  );
};
