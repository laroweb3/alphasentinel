import { cn } from "@/lib/utils";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

interface Position {
  id: string;
  pair: string;
  side: "LONG" | "SHORT";
  entryPrice: number;
  currentPrice: number;
  size: number;
  leverage: number;
  pnl: number;
  pnlPercent: number;
}

interface PositionCardProps {
  position: Position;
}

export const PositionCard = ({ position }: PositionCardProps) => {
  const isProfit = position.pnl >= 0;
  const Icon = position.side === "LONG" ? ArrowUpRight : ArrowDownRight;

  return (
    <div className={cn(
      "p-4 rounded-lg border bg-card/50 gradient-border",
      isProfit ? "border-success/20" : "border-destructive/20"
    )}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className={cn(
            "p-1.5 rounded",
            position.side === "LONG" ? "bg-success/20 text-success" : "bg-destructive/20 text-destructive"
          )}>
            <Icon className="h-4 w-4" />
          </div>
          <span className="font-mono font-bold text-foreground">{position.pair}</span>
          <span className={cn(
            "text-xs px-2 py-0.5 rounded font-mono",
            position.side === "LONG" ? "bg-success/20 text-success" : "bg-destructive/20 text-destructive"
          )}>
            {position.side}
          </span>
        </div>
        <span className="text-xs text-muted-foreground font-mono">{position.leverage}x</span>
      </div>

      <div className="grid grid-cols-2 gap-4 text-sm font-mono">
        <div>
          <p className="text-xs text-muted-foreground mb-1">Entry</p>
          <p className="text-foreground">${position.entryPrice.toLocaleString()}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-1">Current</p>
          <p className="text-foreground">${position.currentPrice.toLocaleString()}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-1">Size</p>
          <p className="text-foreground">${position.size.toLocaleString()}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-1">PnL</p>
          <p className={cn(
            "font-bold",
            isProfit ? "text-success text-glow-success" : "text-destructive text-glow-destructive"
          )}>
            {isProfit ? "+" : ""}{position.pnlPercent.toFixed(2)}%
          </p>
        </div>
      </div>
    </div>
  );
};
