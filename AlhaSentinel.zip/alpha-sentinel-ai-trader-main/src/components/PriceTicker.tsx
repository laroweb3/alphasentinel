import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown } from "lucide-react";

interface TickerItem {
  pair: string;
  price: number;
  change24h: number;
  volume24h: number;
}

interface PriceTickerProps {
  items: TickerItem[];
  selectedPair: string;
  onSelectPair: (pair: string) => void;
}

export const PriceTicker = ({ items, selectedPair, onSelectPair }: PriceTickerProps) => {
  return (
    <div className="flex gap-1 overflow-x-auto scrollbar-hide">
      {items.map((item) => {
        const isUp = item.change24h >= 0;
        const isSelected = item.pair === selectedPair;
        
        return (
          <button
            key={item.pair}
            onClick={() => onSelectPair(item.pair)}
            className={cn(
              "flex-shrink-0 px-4 py-2 rounded-lg font-mono text-sm transition-all",
              "border hover:border-primary/30",
              isSelected 
                ? "bg-primary/10 border-primary/30" 
                : "bg-card/50 border-border"
            )}
          >
            <div className="flex items-center gap-3">
              <span className={cn(
                "font-bold",
                isSelected ? "text-primary" : "text-foreground"
              )}>
                {item.pair}
              </span>
              <div className="flex items-center gap-1">
                {isUp ? (
                  <TrendingUp className="h-3 w-3 text-success" />
                ) : (
                  <TrendingDown className="h-3 w-3 text-destructive" />
                )}
                <span className={cn(
                  "text-xs",
                  isUp ? "text-success" : "text-destructive"
                )}>
                  {isUp ? "+" : ""}{item.change24h.toFixed(2)}%
                </span>
              </div>
            </div>
            <div className="flex items-center justify-between mt-1 text-xs text-muted-foreground">
              <span>${item.price.toLocaleString()}</span>
              <span>Vol: {(item.volume24h / 1000000).toFixed(1)}M</span>
            </div>
          </button>
        );
      })}
    </div>
  );
};
