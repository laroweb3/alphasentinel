import { cn } from "@/lib/utils";
import { TrendingUp, Activity, Zap, XCircle } from "lucide-react";

type Regime = "TREND" | "RANGE" | "HIGH_VOL" | "NO_TRADE";

interface RegimeIndicatorProps {
  regime: Regime;
  confidence?: number;
}

const regimeConfig: Record<Regime, { 
  label: string; 
  icon: typeof TrendingUp; 
  color: string;
  bgColor: string;
  description: string;
}> = {
  TREND: {
    label: "TREND",
    icon: TrendingUp,
    color: "text-success",
    bgColor: "bg-success/10 border-success/30",
    description: "EMA Crossover Active",
  },
  RANGE: {
    label: "RANGE",
    icon: Activity,
    color: "text-primary",
    bgColor: "bg-primary/10 border-primary/30",
    description: "Mean Reversion Mode",
  },
  HIGH_VOL: {
    label: "HIGH VOL",
    icon: Zap,
    color: "text-warning",
    bgColor: "bg-warning/10 border-warning/30",
    description: "Scalp / Small Size",
  },
  NO_TRADE: {
    label: "NO TRADE",
    icon: XCircle,
    color: "text-destructive",
    bgColor: "bg-destructive/10 border-destructive/30",
    description: "Market Conditions Unfavorable",
  },
};

export const RegimeIndicator = ({ regime, confidence = 0.85 }: RegimeIndicatorProps) => {
  const config = regimeConfig[regime];
  const Icon = config.icon;

  return (
    <div className={cn(
      "rounded-lg border p-4 gradient-border",
      config.bgColor
    )}>
      <div className="flex items-center gap-3">
        <div className={cn("p-3 rounded-lg bg-card", config.color)}>
          <Icon className="h-6 w-6" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className={cn("font-mono font-bold text-lg", config.color)}>
              {config.label}
            </span>
            <span className="text-xs text-muted-foreground font-mono">
              {(confidence * 100).toFixed(0)}% conf.
            </span>
          </div>
          <p className="text-sm text-muted-foreground">{config.description}</p>
        </div>
      </div>
      {/* Confidence bar */}
      <div className="mt-3 h-1.5 bg-muted rounded-full overflow-hidden">
        <div 
          className={cn("h-full rounded-full transition-all duration-500", config.color.replace("text-", "bg-"))}
          style={{ width: `${confidence * 100}%` }}
        />
      </div>
    </div>
  );
};
