import { cn } from "@/lib/utils";

interface Trade {
  id: string;
  time: string;
  pair: string;
  side: "LONG" | "SHORT";
  entryPrice: number;
  exitPrice: number;
  pnl: number;
  pnlPercent: number;
}

interface TradeHistoryProps {
  trades: Trade[];
}

export const TradeHistory = ({ trades }: TradeHistoryProps) => {
  return (
    <div className="space-y-2">
      {trades.map((trade) => {
        const isProfit = trade.pnl >= 0;
        return (
          <div
            key={trade.id}
            className="flex items-center justify-between p-3 rounded-lg bg-card/30 border border-border hover:border-primary/30 transition-colors font-mono text-sm"
          >
            <div className="flex items-center gap-4">
              <span className="text-xs text-muted-foreground w-16">
                {new Date(trade.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
              <span className="text-primary font-medium">{trade.pair}</span>
              <span className={cn(
                "text-xs px-2 py-0.5 rounded",
                trade.side === "LONG" 
                  ? "bg-success/20 text-success" 
                  : "bg-destructive/20 text-destructive"
              )}>
                {trade.side}
              </span>
            </div>
            <div className="flex items-center gap-6">
              <div className="text-right">
                <span className="text-xs text-muted-foreground">Entry: </span>
                <span className="text-foreground">${trade.entryPrice.toLocaleString()}</span>
              </div>
              <div className="text-right">
                <span className="text-xs text-muted-foreground">Exit: </span>
                <span className="text-foreground">${trade.exitPrice.toLocaleString()}</span>
              </div>
              <div className={cn(
                "text-right font-bold min-w-20",
                isProfit ? "text-success" : "text-destructive"
              )}>
                {isProfit ? "+" : ""}{trade.pnlPercent.toFixed(2)}%
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
