import { useMemo } from "react";
import { cn } from "@/lib/utils";

interface Order {
  price: number;
  amount: number;
  total: number;
}

interface OrderBookProps {
  pair: string;
}

const generateMockOrders = (basePrice: number, isBid: boolean): Order[] => {
  const orders: Order[] = [];
  let totalAmount = 0;
  
  for (let i = 0; i < 8; i++) {
    const priceOffset = (i + 1) * basePrice * 0.0002 * (isBid ? -1 : 1);
    const price = basePrice + priceOffset;
    const amount = 0.5 + Math.random() * 2;
    totalAmount += amount;
    
    orders.push({
      price,
      amount,
      total: totalAmount,
    });
  }
  
  return isBid ? orders : orders;
};

export const OrderBook = ({ pair }: OrderBookProps) => {
  const basePrice = pair.includes("BTC") ? 97150 : pair.includes("ETH") ? 3265 : 186;
  
  const asks = useMemo(() => generateMockOrders(basePrice, false), [basePrice]);
  const bids = useMemo(() => generateMockOrders(basePrice, true), [basePrice]);
  
  const maxTotal = Math.max(
    ...asks.map((o) => o.total),
    ...bids.map((o) => o.total)
  );

  const formatPrice = (price: number) => {
    if (price >= 1000) return price.toFixed(2);
    if (price >= 100) return price.toFixed(3);
    return price.toFixed(4);
  };

  return (
    <div className="rounded-lg border border-border bg-card/30 overflow-hidden">
      <div className="px-3 py-2 border-b border-border">
        <span className="font-mono text-sm text-foreground">Order Book</span>
      </div>
      
      <div className="grid grid-cols-3 gap-2 px-3 py-1 text-xs text-muted-foreground font-mono border-b border-border/50">
        <span>Price</span>
        <span className="text-right">Amount</span>
        <span className="text-right">Total</span>
      </div>

      {/* Asks (sells) - reversed so lowest ask is at bottom */}
      <div className="max-h-[140px] overflow-hidden">
        {[...asks].reverse().map((order, i) => (
          <div
            key={`ask-${i}`}
            className="relative grid grid-cols-3 gap-2 px-3 py-0.5 text-xs font-mono"
          >
            <div
              className="absolute inset-0 bg-destructive/10"
              style={{ width: `${(order.total / maxTotal) * 100}%`, right: 0, left: 'auto' }}
            />
            <span className="relative text-destructive">{formatPrice(order.price)}</span>
            <span className="relative text-right text-muted-foreground">{order.amount.toFixed(4)}</span>
            <span className="relative text-right text-muted-foreground">{order.total.toFixed(4)}</span>
          </div>
        ))}
      </div>

      {/* Spread / Current price */}
      <div className="px-3 py-2 bg-muted/30 border-y border-border/50">
        <div className="flex items-center justify-between font-mono">
          <span className="text-primary font-bold">${formatPrice(basePrice)}</span>
          <span className="text-xs text-muted-foreground">Spread: 0.01%</span>
        </div>
      </div>

      {/* Bids (buys) */}
      <div className="max-h-[140px] overflow-hidden">
        {bids.map((order, i) => (
          <div
            key={`bid-${i}`}
            className="relative grid grid-cols-3 gap-2 px-3 py-0.5 text-xs font-mono"
          >
            <div
              className="absolute inset-0 bg-success/10"
              style={{ width: `${(order.total / maxTotal) * 100}%`, right: 0, left: 'auto' }}
            />
            <span className="relative text-success">{formatPrice(order.price)}</span>
            <span className="relative text-right text-muted-foreground">{order.amount.toFixed(4)}</span>
            <span className="relative text-right text-muted-foreground">{order.total.toFixed(4)}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
